package ex2.car;

public class CarVo {
	String carNumber;
	String carName;
	String carColor;
	int carSize;
	String carMaker;
	
	public CarVo(String carNumber, String carName, String carColor, int carSize, String carMaker) {
		this.carNumber = carNumber;
		this.carName = carName;
		this.carColor = carColor;
		this.carSize = carSize;
		this.carMaker = carMaker;
	}
}
