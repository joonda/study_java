package ex2.car;

public interface Car {
	public String checkCarInfo(CarVo vo);
	public void regCarInfo(CarVo vo);
	public void modCarInfo(CarVo vo);
	public void delCarInfo(CarVo vo);
}
