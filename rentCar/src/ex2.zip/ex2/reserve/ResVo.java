package ex2.reserve;

public class ResVo {
	String resCarNumber;
	String resDate;
	String useBeginDate;
	String returnDate;
	
	public ResVo(String resCarNumber, String resDate, String useBeginDate, String returnDate) {
		this.resCarNumber = resCarNumber;
		this.resDate = resDate;
		this.useBeginDate = useBeginDate;
		this.returnDate = returnDate;
	}

}
