package ex2.member;

public class MemberVo {
	String id;
	String password;
	String name;
	String address;
	String phoneNum;

	public MemberVo(String id, String password, String name, String address, String phoneNum) {
		this.id = id;
		this.password = password;
		this.name = name;
		this.address = address;
		this.phoneNum = phoneNum;
	}
}

