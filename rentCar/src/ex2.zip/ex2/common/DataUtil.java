package ex2.common;

public class DataUtil {
	public static void encodeData(String data) {
		System.out.println(data + "를 암호화합니다.");
	}
	
	public static void decodeData(String data) {
		System.out.println(data + "를 복호화합니다.");
	}
}
